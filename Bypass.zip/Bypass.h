#include <jni.h>
#include <string>
#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <unordered_map>
#include <cstdlib>
#include <ctime>
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <netdb.h>
#include <sys/mman.h>
#include <unistd.h>
#include <sys/ptrace.h>
#include <unwind.h>
#include <dlfcn.h>
#include <libgen.h>
#include <stdint.h>
#include <cstring>
#include <functional>
#include <sys/stat.h>
#include <fcntl.h>
#include <android/log.h>
#include <sys/ptrace.h>
#include <sys/mman.h>
#include "Main/Tools.h"
#include "Main/Logger.h"
#include "Main/oxorany.h"
// #include "Main/obfuscate.h"
#include "Main/Utils.h"
#include "Main/KittyMemory/MemoryPatch.h"

#include "Main/Macros.h"
#include <unordered_map>
#define targetLibName oxorany("libanogs.so")
#define targetLibName oxorany("libUE4.so")


class LODWORD;
#define LODWORD long

#define PATCH_LIB(libName, offset, hex) \
    do { \
        uintptr_t base = findLibrary(libName); \
        if (base != 0) { \
            uintptr_t addr = base + strtoull(offset, NULL, 16); \
            MemoryPatch::createWithHex(addr, hex).Modify(); \
        } \
   } while(0)


#define _QWORD long
#define _DWORD long
#define _BYTE long
#define _WORD long
#define HOOK_LIB
using namespace std;
#define __int8 char
#define __int16 short
#define __int32 int
#define __int64 long long
#define _BYTE  uint8_t
#define _WORD  uint16_t
#define _DWORD uint32_t
#define _QWORD uint64_t
#define _OWORD uint64_t
#define _BOOL8 uint64_t
char *Offset;
#define ret_zero
#define j_j__free
#define log_suspicious_activity
#define apply_cheat_penalty
#define check_memory_integrity
#define __OFSUB__
#define AnoSDKIoctlOld_0
#define HIWORD
#define JUMPOUT
#define byte_4
#define ARM64_SYSREG
#include <random>
#define _ReadStatusReg
#define BYTE5
#define BYTE4
#define HIBYTE
#define BYTE6
#define sub_95A8204
#define IsMemoryReadable
#define BYTE1
#define BYTE3
#define MEMORY_BASIC_INFORMATION mbi
#define BYTE2
#define _WriteStatusReg
typedef long long int64;
typedef short int16;
uintptr_t ANOGS;
uintptr_t UE5;
DWORD EGLBase = 0;
DWORD EGLSize = 0;
DWORD EGLAlloc = 0;
DWORD libcBase = 0;
DWORD libcSize = 0;
DWORD libcAlloc = 0;
DWORD libUE4Base = 0;
DWORD UE4Base = 0;
DWORD libanogsBase = 0;
uintptr_t libANOBase = 0;
DWORD libanortBase = 0;
DWORD libanogsAlloc = 0;
DWORD libUE4Alloc = 0;
unsigned int libanogsSize = 0;
unsigned int libUE4Size = 0;
DWORD NewBase = 0;
unsigned char shellcode[] = { 0x00, 0x00, 0x80, 0xD2, 0xC0, 0x03, 0x5F, 0xD6 };

#define anogs OBFUSCATE("libanogs.so")


void chRestore()
{
	char mode[] = "0777";
	char *path = "/data/data/com.pubg.imobile/files/ano_tmp";
	char *path2 = "/data/data/com.pubg.imobile/files";
	int m = strtol(mode, 0, 8);
	chmod(path, m);
	chmod(path2, m);
	LOGI(OBFUSCATE("permissions restored"));
}


size_t SRCWALAA(char *s)
{
	static const std::unordered_map < std::string, std::string > replacements = {

		{"1405388", "1407758"},	// new ultimet 
		{"1405586", "1407470"},	// Untamed Celestial set 
		{"1405647", "1407871"},	// Marmoris X-Suit 
		{"1405196", "1407841"},	// new hani bagger 
		{"1405807", "1405983"},	// Poseidon X-Suit
		{"1405548", "1407330"},	// Spectral admiral set [time wala]
		{"1405113", "1407906"},	// phoenix x suit [time wala]
		{"403041", "1407142"},	// Silvanus X-Suit (7-Star)
		{"403224", "1406727"},	// pri
		{"403006", "1406398"},	// Flamewraith set[same] parmanent 
		{"1402154", "1405934"},	// Godzilla Set
		{"1402155", "1410826"},	// Mask
		{"403042", "1405092"},	// Vampyra Set
		{"403033", "1407512"},	// Dravion X-Suit (7-Star)
		{"403211", "1407695"},	// Winter Highness Set 
		{"403163", "1407330"},	// Spectral admiral set[ permanent]
		{"403042", "1407695"},	// Macabre Valentine Set

		{"403006", "1405870"},	// Dragonflame Berserker Set
		{"1406748", "1407512"},	// Dravion X-Suit (7-Star)
		{"1405269", "1407695"},	// Winter Highness Set
		{"404151", "1407049"},	// BAPE X PUBGM CAMO Shorts
		{"1405884", "1407330"},	// Spectral admiral set [permanent]
		{"1405113", "1407329"},	// The Reaper's End Set
		{"1405072", "1407695"},	// Macabre Valentine Set
		{"403003", "1407726"},	// The hermit's Chrysalis Set 1
		{"403020", "1407470"},	// Golden Pharaoh Divine Set
		{"403032", "1407682"},	// The hermit's Chrysalis Set 2
		{"403224", "1407387"},	// Soul-Eater Underworld King
		{"403160", "1407459"},	// Zero Combat Suit
		{"403002", "1400687"},	// Phantom Night Shinigami Set
		{"403198", "1407703"},	// Spectral Dreamweaver Set

		{"403124", "1407704"},	// Spectral Duskbride Set 
		{"1404008", "1407277"},	// Underworld Traveler Set
		{"403193", "1407276"},	// Dawn Flora Divine Set
		{"403192", "1406824"},	// Holy Flame Igni Divine Set
		{"403153", "1407279"},	// Arabian Traveler
		{"1400043", "1407536"},	// Ruins Hunter
		{"403162", "1407277"},	// Flame Ancient God
		{"404056", "1404191"},	// Trendy Walker Pants
		{"403177", "1407079"},	// Blissful Fool
		{"1400100", "1400782"},	// Ice Crystal Core
		{"403195", "1400569"},	// BAPE MIX CAMO HOODIE
		{"403163", "1404049"},	// BAPE X PUBGM Camouflage Shark Jacket
		{"404001", "1404050"},	// BAPE X PUBGM Camouflage Pants
		{"404049", "1404002"},	// Bape City Camo Pants
		{"404026", "1400650"},	// BAPE MIX CAMO SHORTS
		{"405053", "1404051"},	// BAPE X PUBGM Camouflage Shoes
		{"405022", "1404003"},	// BAPE Sta Mid
		{"402046", "474031"},	// BAPE Sta Mid
		// //////////{==============[Cap]==================

		{"401008", "1410686"},	// /Spectral admiral cover

		// ///////////////////Maks//////////////////////====================================

		{"1400030", "1410072"},	// Flamewraith mask
		{"402020", "1410072"},	// Flamewraith mask
		{"930402020", "1410072"},
		{"441400030", "1410072"},
		// ///////////////////////////////////////////////====================================


		{"502001", "1502001014"},	// helmet
		{"502002", "1502002014"},	// helmet
		{"502003", "1502003014"},	// helmet

		{"501001", "1501001711"},	// Backpack (Lv. 1) 
		{"501002", "1501002711"},	// Backpack (Lv. 2) 
		{"501003", "1501003711"},	// Backpack (Lv. 3) 

		// --- DACIA (Sedan) ---
		{"1903001", "1903089"},	// Dodge Charger SRT Hellcat - Tuscan Torque | 
								// 

		// --- COUPE RB (Sports Car) ---
		{"1961001", "1961153"},	// Bugatti Bolide (blue - Mirror Finish)

		// --- UAZ (Off-Road) ---
		{"1908001", "1908078"},	// Maserati Levante fire
		// --- MIRADO (Open Top) ---
		{"1915004", "1915008"},	// Bentley Continental GTC Mulliner
								// (Holocrystal)

		{"1907001", "1907054"},	// Buggy
		{"1907002", "1907055"},	// Buggy
		{"1907003", "1907056"},	// Buggy
		{"1907004", "1907058"},	// Buggy
		{"1907005", "1907059"},	// Buggy
		{"1907006", "1907054"},	// Buggy

		// ////////////////////////================[Call Horse]===============
		{"1987006", "1987002"},
		{"1987005", "1987002"},
		{"1987001", "1987002"},

		// //////////////////////=================[end]===================

		// --- MOTORCYCLE (2-Seat) ---
		{"1901001", "1901073"},	// DUCATI Panigale V4S
		{"1901001", "1901092"},	// Indian FTR R Carbon
		{"1901001", "1901077"},	// Bulma's Motorcycle (Dragon Ball)

		// --- MONSTER TRUCK ---
		{"1953001", "1953008"},	// Sea Wrath (Monster Look - Max Level)
		{"1953001", "1953016"},	// Starlight Gleam (Latest 2025 - Max Level)
		{"1953001", "1953011"},	// Nemesis Monster Truck (Dark Look)

		// --- MINI BUS ---
		{"1904001", "1904016"},	// NewJeans Minibus
		{"1904001", "1904018"},	// Frieren: Beyond Journey's End Bus
		{"602130", "4151124"},	// Spirited Veil Glider (Latest 2025)


		// //======ordinary wingman==========
		{"181101000", "181101021"},	// ordinary wingman 

		{"10100400", "1101004236"},	// Roaring Immolation
		{"10100100", "1101001265"},	// AKM 
		{"10100300", "1101003227"},	// phoenix rise SCAR 
		{"10100800", "1101008154"},	// M762 
		{"10200200", "1102002424"},	// UMP 
		{"10300300", "1103003079"},	// AWM 
		{"10300100", "1103001202"},	// Kar98 
		{"10500100", "1105001069"},	// m249 
		{"10300200", "1103002030"},	// M24 
		{"10200100", "1102001120"},	// UZI 
		{"10500200", "1105002091"},	// DP-28 
		{"10110200", "1101102025"},	// ACE32 
		{"10100500", "1101005098"},	// Groza 
		{"10400400", "1104004035"},	// DBS 
		{"10400300", "1104003037"},	// S12K 
		{"10501000", "1105010019"},	// MG3 
		{"10100600", "1101006075"},	// aug 
		{"10200500", "1102005064"},	// bizon
		{"10200300", "1102003100"},	// vector
		{"10210500", "1102105028"},	// P90
		{"10101200", "1101012033"},	// Honey Badger 
		{"10100900", "1101009012"},	// FAMAS
		{"10301200", "1103012039"},	// AMR
		{"10300500", "1103005037"},	// Mini14
		{"10300400", "1103004058"},	// SKS
		{"10300900", "1103009028"},	// SLR
		{"10410100", "1104101001"},	// M1014

		// GLIDER SKIN//
		{"703001", "1401621"},	// Glider parachute 🔅
		{"703001", "1401621"},	// Glider 🔅

		{"4151001", "4151137"},	// Glider blood raven 🐦‍⬛ 🔅
		{"4151001", "4151137"},	// Glider 🔅

		{"4151002", "4151134"},	// Glider parachute 🔅
		{"4151002", "4151134"},	// Glider 🔅

		{"4151003", "4151136"},
		{"4151003", "4151136"},	// /Imperial phoenix glider
		/* 

		   ////Guns attachment m416//// {"20300100","1010042299"},//Red Dot
		   {"20301400","1010042296"},//3x {"20301500","1010042294"},//6x

		   // ---- ATTACHMENTS (Roaring Immolation M416) ----\\

		   {"20300800","1010042292"},//Sight {"20500500","1010042293"},//Stock
		   {"291004","1010042291"},//Magazine
		   {"202002","1010042314"},//Vertical {"202001","1010042309"},//Angled
		   Foregrip {"202004","1010042316"},//Light Grip
		   {"202005","1010042317"},//Half Grip {"202006","1010042310"},//Thumb
		   Grip {"201010","1010042307"},//Flash Hider
		   {"201011","1010042308"},//Suppressor
		   {"201009","1010042306"},//Compensator
		   {"204012","1010042304"},//QuickDraw Mag
		   {"204011","1010042300"},//Extended Mag
		   {"204013","1010042305"},//Extended QuickDraw Mag
		   {"203018","1010042319"},//Canted Sight
		   {"202007","1010042318"},//Laser Sight */
	};

	auto it = replacements.find(s);
	if (it != replacements.end())
	{
		strcpy(s, it->second.c_str());
		return strlen(s);
	}
	return strlen(s);
}

// /////////////[STRUCTURE CODE]===========================================
__int64 BATTLEXFIRE()
{
	return 0LL;
}

__int64 DEATHCORE()
{
	return 0LL;
}


// ==============================================================================/
int32_t f_mprotect(uintptr_t addr, size_t len, int32_t prot)
{
	size_t page_size = static_cast < size_t > (4096);
	void *start = reinterpret_cast < void *>(addr & -page_size);
	uintptr_t end = (addr + len + page_size - 1) & -page_size;
	return mprotect((void *)start, end - reinterpret_cast < uintptr_t > (start), prot);
}

// ==============================================================================/
int Hook_VTable(uintptr_t VTableAddr, void *Hook_Sub, void **Original_Sub)
{
	if (!VTableAddr || !Hook_Sub)
	{
		return 1;
	}
	void **VTable = (void **)VTableAddr;
	void *Original = *VTable;
	if (Original_Sub)
	{
		*Original_Sub = Original;
	}
	f_mprotect((uintptr_t) VTableAddr, sizeof(void *), PROT_READ | PROT_WRITE);
	*VTable = Hook_Sub;
	f_mprotect((uintptr_t) VTableAddr, sizeof(void *), PROT_READ);
	return 0;
}

// ==============================================================================/
size_t getLibrarySize(const char *libraryName)
{
	FILE *mapsFile = fopen("/proc/self/maps", "r");
	if (mapsFile == nullptr)
	{
		return 0;
	}

	char line[256];
	size_t size = 0;
	uintptr_t startAddr = 0, endAddr = 0;
	while (fgets(line, sizeof(line), mapsFile))
	{
		if (strstr(line, libraryName))
		{
			sscanf(line, "%lx-%lx", &startAddr, &endAddr);
			size = endAddr - startAddr;
			break;
		}
	}

	fclose(mapsFile);
	return size;
}

// ==============================================================================/
// ==============================================================================/
// =============================================================================/


// =================================================================//


// =================================================================//


// =================================================================//
// ================================================================================

// #include "Main/encrypt_protect.h"
void *KAMLESH_thread(void *)
{
	UE5 = Tools::GetBaseAddress("libUE4.so");
	while (!UE5)
	{
		UE5 = Tools::GetBaseAddress("libUE4.so");
		sleep(1);
	}

	ANOGS = Tools::GetBaseAddress("libanogs.so");
	while (!ANOGS)
	{
		ANOGS = Tools::GetBaseAddress("libanogs.so");
		sleep(1);
	}
	do
	{
		sleep(1);
	}
	while (!isLibraryLoaded(targetLibName));
	libanogsBase = findLibrary("libanogs.so");
	libUE4Base = findLibrary("libUE4.so");
	while (!isLibraryLoaded("libUE4.so"))
	{
		sleep(1);
	}
	while (!isLibraryLoaded("libanogs.so"))
	{
		sleep(1);
	}
	while (!isLibraryLoaded("libanort.so"))
	{
		sleep(1);
	}
	libanogsAlloc = (DWORD) malloc(libanogsSize);
	libUE4Alloc = (DWORD) malloc(libUE4Size);
	memcpy((void *)libanogsAlloc, (void *)libanogsBase, libanogsSize);
	memcpy((void *)libUE4Alloc, (void *)libUE4Base, libUE4Size);
	LOGI(" @OWNERHUBEE BYPASS LOADED");
	LOGI("UE4 size : 0x%04X | ANOGS size : 0x%04X", libUE4Size, libanogsSize);
#if defined(__aarch64__)
	LOGI("====================================================");
	LOGI("=====< LIBRARY LOADED BY @OWNERHUBEE >======");
	LOGI("====================================================");
	HOOK_LIB_NO_ORIG("libUE4.so", "0xc4dfb90", SRCWALAA);	// SKIN HOOK MOVED 
															// HERE

	// ==================== SUB INSTRUCTIONS ====================
	PATCH_LIB("libanogs.so", "0x4D6480", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D758C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	// ==================== LDR INSTRUCTIONS ====================
	PATCH_LIB("libanogs.so", "0x4D5190", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D54AC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D5818", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D5838", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D677C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D6784", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D6AF8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D6B08", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D6B18", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D715C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D7168", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D7588", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	// ==================== CBZ INSTRUCTIONS ====================
	PATCH_LIB("libanogs.so", "0x4D54A8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D54B0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D64A0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D64A8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D7154", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D75AC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D75B4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	// ==================== MOV INSTRUCTIONS ====================
	PATCH_LIB("libanogs.so", "0x4D5144", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D54A0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D54A4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D54B4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D54BC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D54C0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D5804", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D5820", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D5824", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D5E88", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D5E90", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D5E94", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D5E98", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D5EAC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D6200", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D6208", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D64B8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D64BC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D64C0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D64C4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D64C8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D64D4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D6774", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D6780", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D6AFC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D6B00", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D6B0C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D7150", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D7174", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D75B8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	// ==================== BL INSTRUCTIONS ====================
	PATCH_LIB("libanogs.so", "0x4D5148", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D5494", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D54C4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	PATCH_LIB("libanogs.so", "0x4D5834", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D5E8C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D61EC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D61F4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D6214", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D64D0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D6768", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D6790", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D6B04", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D6B14", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D7580", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	// ==================== SUB INSTRUCTIONS ====================
	PATCH_LIB("libanogs.so", "0x4D85CC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D85D0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D8B6C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	// ==================== LDR INSTRUCTIONS ====================
	PATCH_LIB("libanogs.so", "0x4D85A0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D8B14", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D8B20", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D8B24", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D8B38", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D93C0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D93D0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D93E4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D98B8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D98BC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	// ==================== CBZ INSTRUCTIONS ====================
	PATCH_LIB("libanogs.so", "0x4D7B98", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D7BBC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D7BD8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D8234", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D8548", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	// Note: Baki ke code strings me pure formatting blocks ensure kiye gaye
	// hain
	// ==================== SUBS INSTRUCTIONS ====================
	// Image 1: SUBS W21, W21, #1 loop tracking control register modifier
	PATCH_LIB("libanogs.so", "0x4D9CC8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	// ==================== CBZ INSTRUCTIONS ====================
	// Image 2: CBZ W8, loc_4D9FC4 condition bypass
	PATCH_LIB("libanogs.so", "0x4D9E7C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	// Image 3: CBZ X0, loc_4DA1B4 dynamic conditional branches
	PATCH_LIB("libanogs.so", "0x4DA118", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4DA1A4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	// Image 4: CBZ validation routines
	PATCH_LIB("libanogs.so", "0x4DA474", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4DA478", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	// ==================== LDR INSTRUCTIONS ====================
	// Image 1: Reference offsets tracking sub pointers
	PATCH_LIB("libanogs.so", "0x4D9CD8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D9CDC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	// Image 3: Array elements context loading offsets
	PATCH_LIB("libanogs.so", "0x4DA130", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4DA13C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4DA19C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	// Image 4: Function frame dependencies
	PATCH_LIB("libanogs.so", "0x4DA484", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4DA48C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	// Image 5: Epilogue stack frame reconstruction
	PATCH_LIB("libanogs.so", "0x4DA950", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4DA96C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	// ==================== MOV & BL INSTRUCTIONS ====================
	// Image 1: Main branch link tracking calls
	PATCH_LIB("libanogs.so", "0x4D9CAC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D9CB4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D9CE4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	// Image 2: Sub-routine jumps and assignment tracking
	PATCH_LIB("libanogs.so", "0x4D9E5C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D9E60", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4D9E94", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	// Image 5: External runtime linkages
	PATCH_LIB("libanogs.so", "0x4DA974", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x4DA978", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	// termination fix part 2
	PATCH_LIB("libanogs.so", "0x37273C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372AE4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372B3C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x3731F8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x3731FC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x37413C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x37203C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x37272C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372748", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372758", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372AF0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372B10", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372B38", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x3731C0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x374124", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x374138", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372750", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372754", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372B0C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372B1C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372B2C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x3731C4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x3731C8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x37410C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x374110", "00/x00/x80/xD2/xC0/x03/x5F/xD6");



	// 10 years + 1 day
	PATCH_LIB("libanogs.so", "0x37273C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372AE4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372B3C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x3731F8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x3731FC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x37413C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x37203C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x37272C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372748", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372758", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372AF0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372B10", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372B38", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x3731C0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x374124", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x374138", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372750", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372754", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372B0C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372B1C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x372B2C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x3731C4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x3731C8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x37410C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x374110", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x51B9B8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x51B9D4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x51B9E0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x51BC44", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x51BC78", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x51BF34", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x51C7DC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libanogs.so", "0x51CA30", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	// Flag delay 1 day & 7 day 
	PATCH_LIB("libTBlueData.so", "0x985B0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x94828", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x99D64", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x99D84", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x99D88", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x99834", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x9764C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x97650", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x9719C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x952A0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x952A8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x94E44", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x94E54", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x94834", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x94848", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x9484C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x94854", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x94858", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x9485C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x99D44", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x99D78", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x9980C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x9983C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x985C8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x97630", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x9765C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x9718C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x97190", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x952C4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x94E0C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x94E4C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x94E60", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x94830", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x99D6C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x99D74", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x96264", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x99D68", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x99D80", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x985C0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x97658", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x97180", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x97194", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x971A0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x952C0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x94E24", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x94E48", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x94E58", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x94844", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x94850", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x94860", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x9486C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x94884", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	// termination fix 
	PATCH_LIB("libTBlueData.so", "0x4C714", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x4C728", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA6D2C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA6D30", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA6D54", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA6D60", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA6D64", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA63A0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA63A4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA63C8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA63CC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA63DC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA5A08", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA5A0C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA5A1C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA5A28", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA5A2C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA5A40", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA5A44", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA6D24", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA6D3C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA63AC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA63D4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA63D8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA5A58", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x4C704", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x4C724", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA63D0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x4C708", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x4C71C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA6D34", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA6D68", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA63A8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA63D0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA63E0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA63E8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA5A10", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA5A20", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA5A24", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA5A30", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA5A48", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0xA5A54", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	// 10 years 
	PATCH_LIB("libTBlueData.so", "0x1B3AB8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B3AE4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B364C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B3650", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B3660", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B3380", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B3384", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B30A4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B30A8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B30AC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B30B0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B30BC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2E0C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2E2C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2E3C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2B98", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2B9C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2BA0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2BA4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2BAC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2970", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	// Trick_LIB("libTBlueData.so", "0x1B2974",
	// "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2990", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B237C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2380", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2384", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2388", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B239C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B23AC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2258", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2284", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B1D58", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B3AEC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B3664", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B3360", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B3388", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B30C0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B30FC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2E30", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2BA8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2938", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B297C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B238C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2254", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2288", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B1D44", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B1D54", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B1D6C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B3AA0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	PATCH_LIB("libTBlueData.so", "0x1B3AA8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B3AC4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B3AD4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B3AE0", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B363C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B3644", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B3668", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B366C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B3674", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B3364", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B337C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B338C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B30F4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B30FC", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2E24", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2E28", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2BB8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2BD8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B293C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2940", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B294C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2950", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2954", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2960", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2964", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2968", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B296C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2980", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2984", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B23A4", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B23A8", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2248", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B224C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2264", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2268", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2274", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B227C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B2280", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B1D38", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B1D3C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B1D40", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B1D48", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B1D4C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B1D5C", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B1D68", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B1D70", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B1D74", "00/x00/x80/xD2/xC0/x03/x5F/xD6");
	PATCH_LIB("libTBlueData.so", "0x1B1D78", "00/x00/x80/xD2/xC0/x03/x5F/xD6");

	chRestore();				// restore permissions
	sleep(55);					// lobby wait
	// chfiles();//change permissions + 7day fix
	// ================================================================================
	LOGI(OBFUSCATE("Done"));
#endif

	return NULL;
}


__attribute__ ((constructor))
	 void mainload()
{
	pthread_t ptid;
	pthread_create(&ptid, NULL, KAMLESH_thread, NULL);

}
